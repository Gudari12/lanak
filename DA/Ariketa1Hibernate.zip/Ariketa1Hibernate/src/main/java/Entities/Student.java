package Entities;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.annotations.Formula;
import jakarta.persistence.*;

@Entity
@Table(name = "student")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer idStudent;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;
    
    @Column
    private String email;

    @Embedded
    private Address address;

    @Column(name = "birthdate")
    private LocalDate birthDate;

    @Formula("floor(datediff(curdate(), birthdate)/365)")
    private Integer age;

    @ElementCollection
    @CollectionTable(
        name = "student_phone",
        joinColumns = @JoinColumn(name = "student_id")
    )
    @Column(name = "student_phone")
    private List<String> phones;

    public Student() {}

    public Student(String firstName, String lastName, String email, Address address, LocalDate birthDate) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.address = address;
        this.birthDate = birthDate;
    }

    public Integer getIdStudent() {
        return idStudent;
    }
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
        
    public void setIdStudent(Integer idStudent) {
        this.idStudent = idStudent;
    }

    public List<String> getPhones() {
        return phones;
    }

    public void setPhones(List<String> phones) {
        this.phones = phones;
    }

    @Override
    public String toString() {
        return "Student [idStudent=" + idStudent + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
                + email + ", address=" + address + ", birthDate=" + birthDate + ", age=" + age + ", phones=" + phones
                + "]";
    }
}