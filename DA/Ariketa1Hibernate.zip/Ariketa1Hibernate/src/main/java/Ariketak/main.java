package Ariketak;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import Entities.*;

public class main {

    public static void main(String[] args) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("NirePersistentziaUnitatea");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();

        Student s1 = new Student("Mikel", "Clavero", "mikelclavero@example.com", 
                new Address("Kale 1", "3", "Santurtzi", "48980"), LocalDate.of(2004, 3, 23));

        em.persist(s1);
        em.getTransaction().commit();
        
        System.out.println("Ikasle berri sortutaren id: " + s1.getIdStudent());
        
        em.getTransaction().begin();

        Student s2 = new Student("Ainhoa", "Perez", "ainhoaperez@example.com",
                new Address("Kale 2", "4", "Santurtzi", "48980"), LocalDate.of(1998, 2, 20));

        em.persist(s2);
        em.getTransaction().commit();

        Student find = em.find(Student.class, s2.getIdStudent());
        System.out.println("Ikaslea: " + find);
        
        em.getTransaction().begin();

        Student aldatu = em.find(Student.class, 1L);

        if (aldatu != null) {
            aldatu.setFirstName("Miguel Angel");
        }

        em.getTransaction().commit();
        
        System.out.println(1L +" eguneratuta: " + aldatu);

        em.getTransaction().begin();
        
        Student ezabatu = em.find(Student.class, 1L);

        if (ezabatu != null) {
            em.remove(ezabatu);
        }

        em.getTransaction().commit();
        
        System.out.println(1L+" ikaslea ezabatuta");
        
        em.getTransaction().begin();

        Student s3 = new Student("Arantza", "Fernandez", "arantzafernandez@example.com", 
                new Address("Kale 3", "5", "Santurtzi", "48980"),
                LocalDate.of(1993, 7, 11));
        
        List<String> phoneNumbers3 = new ArrayList<>();
        phoneNumbers3.add("123456789");
        phoneNumbers3.add("987654321");
        
        s3.setPhones(phoneNumbers3);

        em.persist(s3);
        
        em.getTransaction().commit();
        
        System.out.println("Ikasle berri sortutaren id: " + s3.getIdStudent());
        em.getTransaction().begin();
        
        phoneNumbers3.add("666634765");
        
        s3.setPhones(phoneNumbers3);
        
        em.merge(s3);
        
        em.getTransaction().commit();
        
        System.out.println("Telefono berri bat gehituta");
        em.getTransaction().begin();
        
        s3.getPhones().clear();
        em.merge(s3);
        
        em.getTransaction().commit();
        
        System.out.println("Azken ikaslearen telefonoak ezabatuta");
        
        em.getTransaction().begin();
        
        s3.setAddress(new Address("Kale 4", "6", "Santurtzi", "48980"));
        
        em.getTransaction().commit();

        System.out.println("Azken ikaslearen address aldatuta");
        
        em.close();
        emf.close();
    }
}