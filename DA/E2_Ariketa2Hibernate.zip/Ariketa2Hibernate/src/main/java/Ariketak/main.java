package Ariketak;

import Entities.*;
import jakarta.persistence.*;

public class main {

    public static void main(String[] args) {

        EntityManagerFactory emf =
                Persistence.createEntityManagerFactory("ORM01_PU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        Student s1 = new Student("Mikel");
        Tuition t1 = new Tuition(1200.0);

        s1.setTuition(t1);

        em.persist(s1);

        em.getTransaction().commit();

        System.out.println("Student created with ID: " + s1.getId());
        em.getTransaction().begin();

        Student studentToDelete = em.find(Student.class, s1.getId());
        em.remove(studentToDelete);

        em.getTransaction().commit();

        System.out.println("Student and Tuition deleted");
        em.getTransaction().begin();

        University uni = new University("UPV/EHU", "Bilbao");
        Student s2 = new Student("Ane");

        uni.addStudent(s2);
        em.persist(uni);
        em.persist(s2);

        em.getTransaction().commit();

        int studentId = s2.getId();
        int universityId = uni.getId();

        System.out.println("Student " + studentId +
                           " assigned to University " + universityId);
        em.getTransaction().begin();

        Student st = em.find(Student.class, studentId);
        em.remove(st);

        em.getTransaction().commit();

        System.out.println("Student deleted, University preserved");
        em.getTransaction().begin();

        Student s3 = new Student("Jon");

        Course c1 = new Course("Databases", "6");
        Course c2 = new Course("Java", "6");

        s3.addCourse(c1);
        s3.addCourse(c2);

        em.persist(c1);
        em.persist(c2);
        em.persist(s3);

        em.getTransaction().commit();

        System.out.println("Student enrolled in courses");
        em.getTransaction().begin();

        Student st2 = em.find(Student.class, s3.getId());
        em.remove(st2);

        em.getTransaction().commit();

        System.out.println("Student deleted, courses preserved");

        em.close();
        emf.close();
    }
}
