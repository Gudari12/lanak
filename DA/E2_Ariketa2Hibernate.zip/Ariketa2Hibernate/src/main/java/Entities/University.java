package Entities;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "university")
public class University {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String zipCode;

    @OneToMany(mappedBy = "university", cascade = CascadeType.REMOVE)
    private List<Student> students = new ArrayList<>();

    public University() {}

    public University(String name, String city) {
        this.name = name;
        this.city = city;
    }

    public int getId() {
        return id;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void addStudent(Student s) {
        students.add(s);
        s.setUniversity(this);
    }
}
