package Entities;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "course")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private String credits;

    @ManyToMany(mappedBy = "courses")
    private Set<Student> students = new HashSet<>();

    public Course() {}

    public Course(String name, String credits) {
        this.name = name;
        this.credits = credits;
    }

    public int getId() {
        return id;
    }
    
    public Set<Student> getStudents() {
        return students;
    }
}
