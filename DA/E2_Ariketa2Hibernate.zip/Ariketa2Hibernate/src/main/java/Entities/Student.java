package Entities;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "student")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "tuition_id")
    
    private Tuition tuition;
    @ManyToOne
    @JoinColumn(name = "university_id")
    private University university;
    
    @ManyToMany
    @JoinTable(
        name = "student_course",
        joinColumns = @JoinColumn(name = "student_id"),
        inverseJoinColumns = @JoinColumn(name = "course_id")
    )
    private Set<Course> courses = new HashSet<>();

    public Student() {}

    public Student(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setTuition(Tuition tuition) {
        this.tuition = tuition;
    }

    public void setUniversity(University university) {
        this.university = university;
    }

    public void addCourse(Course c) {
        courses.add(c);
        c.getStudents().add(this);
    }
}
