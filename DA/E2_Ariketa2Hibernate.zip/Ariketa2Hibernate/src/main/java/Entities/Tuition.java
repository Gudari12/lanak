package Entities;

import jakarta.persistence.*;

@Entity
@Table(name = "tuition")
public class Tuition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private Double fee;

    public Tuition() {}

    public Tuition(Double fee) {
        this.fee = fee;
    }

    public int getId() {
        return id;
    }

    public Double getFee() {
        return fee;
    }

    public void setFee(Double fee) {
        this.fee = fee;
    }
}
